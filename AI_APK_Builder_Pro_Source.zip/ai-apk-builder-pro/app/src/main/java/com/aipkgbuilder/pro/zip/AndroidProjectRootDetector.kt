package com.aipkgbuilder.pro.zip

import java.io.File

/** Pure filesystem-only Android/Gradle root detector, independently unit-testable. */
object AndroidProjectRootDetector {
    fun detect(workspace: File): File? {
        if (!workspace.isDirectory) return null
        val candidates = mutableMapOf<String, Pair<File, Int>>()
        workspace.walkTopDown().maxDepth(ProjectProcessor.MAX_NESTING).onEnter { dir ->
            dir == workspace || (!dir.name.startsWith(".") && dir.name !in setOf("build", ".gradle", "node_modules"))
        }.forEach { item ->
            if (!item.isDirectory) return@forEach
            val list = item.list() ?: return@forEach
            val hasSettings = list.any { it == "settings.gradle" || it == "settings.gradle.kts" }
            val hasRootBuild = list.any { it == "build.gradle" || it == "build.gradle.kts" }
            val hasWrapper = File(item, "gradlew").isFile && File(item, "gradlew.bat").isFile && File(item, "gradle/wrapper/gradle-wrapper.properties").isFile && File(item, "gradle/wrapper/gradle-wrapper.jar").isFile
            val hasManifest = File(item, "src/main/AndroidManifest.xml").isFile ||
                item.walkTopDown().maxDepth(5).any { it.isFile && it.name == "AndroidManifest.xml" }
            val hasAndroidPlugin = list.any { it == "build.gradle" || it == "build.gradle.kts" } &&
                (File(item, "build.gradle").takeIf { it.isFile }?.readTextBounded()?.contains("com.android") == true ||
                    File(item, "build.gradle.kts").takeIf { it.isFile }?.readTextBounded()?.contains("com.android") == true)
            var score = 0
            if (hasSettings) score += 8
            if (hasRootBuild) score += 3
            if (hasWrapper) score += 4
            if (hasManifest) score += 4
            if (hasAndroidPlugin) score += 3
            if (score >= 7) candidates[item.canonicalPath] = item to score
        }
        return candidates.values.sortedWith(
            compareByDescending<Pair<File, Int>> { it.second }.thenBy { depthFrom(workspace, it.first) }
        ).firstOrNull()?.first
    }

    private fun depthFrom(root: File, file: File): Int =
        runCatching { root.toPath().relativize(file.toPath()).nameCount }.getOrDefault(Int.MAX_VALUE)

    private fun File.readTextBounded(maxBytes: Long = 1024L * 1024L): String =
        if (isFile && length() <= maxBytes) runCatching { readText(Charsets.UTF_8) }.getOrDefault("") else ""
}
