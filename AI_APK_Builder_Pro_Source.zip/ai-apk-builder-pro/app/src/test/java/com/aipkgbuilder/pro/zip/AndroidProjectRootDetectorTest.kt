package com.aipkgbuilder.pro.zip

import org.junit.Assert.*
import org.junit.Test
import java.io.File
import java.nio.file.Files

class AndroidProjectRootDetectorTest {
    @Test fun detectsNestedProjectRoot() {
        val temp = Files.createTempDirectory("root-detection").toFile()
        try {
            val root = File(temp, "download/outer/AndroidApp").apply { mkdirs() }
            File(root, "settings.gradle.kts").writeText("rootProject.name = \"Fixture\"\ninclude(\":app\")")
            File(root, "build.gradle.kts").writeText("plugins { id(\"com.android.application\") version \"8.13.2\" apply false }")
            File(root, "gradle/wrapper").mkdirs()
            File(root, "gradle/wrapper/gradle-wrapper.properties").writeText("distributionUrl=https\\://services.gradle.org/distributions/gradle-8.13-bin.zip")
            File(root, "gradlew").writeText("#!/bin/sh\nexit 0\n")
            File(root, "app/src/main").mkdirs()
            File(root, "app/src/main/AndroidManifest.xml").writeText("<manifest xmlns:android=\"http://schemas.android.com/apk/res/android\"><application /></manifest>")
            assertEquals(root.canonicalFile, AndroidProjectRootDetector.detect(temp)?.canonicalFile)
        } finally { temp.deleteRecursively() }
    }

    @Test fun ignoresUnrelatedDirectoriesAndReturnsNull() {
        val temp = Files.createTempDirectory("no-project").toFile()
        try {
            File(temp, "notes/AndroidManifest.xml").apply { parentFile.mkdirs(); writeText("not a Gradle project") }
            assertNull(AndroidProjectRootDetector.detect(temp))
        } finally { temp.deleteRecursively() }
    }
}
