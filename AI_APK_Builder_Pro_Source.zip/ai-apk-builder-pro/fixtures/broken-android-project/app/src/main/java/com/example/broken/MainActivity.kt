package com.example.broken

import android.app.Activity
import android.os.Bundle
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Intentional fixture failure: unresolved reference `thisActivity`.
        setContentView(TextView(thisActivity).apply { text = "Broken fixture" })
    }
}
