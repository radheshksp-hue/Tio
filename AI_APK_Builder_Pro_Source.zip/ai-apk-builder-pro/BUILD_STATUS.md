# Build Status and 12-Error Prevention Checklist

Last updated: 2026-10-16

## Honest verification status

- **PASSED (executed):** 16/16 offline project/workflow smoke checks via `python3 tools/validate_project.py`.
- **PASSED (executed):** AndroidManifest.xml parses as well-formed XML.
- **PASSED (executed):** the root workflow parses as YAML and includes `push` and `workflow_dispatch` triggers.
- **PASSED (executed):** targeted Kotlin CLI harnesses previously exercised the production ZIP-root detector, secret redactor/file policy, and patch validator under stated test-harness constraints (details in `TEST_REPORT.md`).
- **NOT TESTED:** `./gradlew --version`, `./gradlew tasks`, dependency resolution, Kotlin/Compose compilation, `assembleDebug`, APK inspection, and device launch. This environment has no Android SDK or installed Gradle and DNS/network downloads are unavailable.
- **NOT TESTED:** real GitHub Actions run, artifact upload/download, GitHub API permissions, Release-asset workflow integration, and Gemini requests; no user credentials were provided.
- **KNOWN DELIVERY LIMITATION:** `gradle/wrapper/gradle-wrapper.jar` is absent. The checked-in `gradlew` is explicitly a SHA-256-verifying Gradle 8.13 bootstrap script, not the official wrapper. The root GitHub Actions workflow attempts to generate the official wrapper from that verified distribution before building. For a fully self-contained Android Studio project, generate and commit the official wrapper JAR on a network-enabled machine.

## Twelve-error prevention checklist

1. **Obsolete SDK `tools` package:** workflow checks the runner SDK and `sdkmanager`, installs `platform-tools`, `platforms;android-36`, and `build-tools;36.0.0`; it does not request the obsolete `tools` package. **Static check passed; hosted runner not tested.**
2. **Invalid Actions YAML:** root workflow parsed by PyYAML; includes push and manual triggers. **Passed static parse; GitHub-hosted workflow not tested.**
3. **Gradle cache setup order:** checkout occurs first and the root build/wrapper properties exist before `setup-java` Gradle caching. No custom cache action is used. **Inspected; hosted cache not tested.**
4. **Incompatible Gradle version:** AGP is pinned to 8.13.2 and wrapper distribution to Gradle 8.13; JDK 17 is configured. **Version declarations inspected; actual build compatibility not tested here.**
5. **Missing app Gradle file:** `app/build.gradle.kts` exists and workflow checks it before building. **Passed.**
6. **Missing `gradlew`/wrapper JAR:** scripts/properties exist, but wrapper JAR is not included. Workflow tries to generate the official wrapper using the SHA-256-checking Gradle 8.13 bootstrap. **Partially mitigated; self-contained wrapper criterion NOT PASSED until generated JAR is committed.**
7. **Wrong manifest path / nested app directory:** standard `app/src/main/AndroidManifest.xml` exists; workflow checks exact path and root files. **Passed static check; remote build not tested.**
8. **`gradlew: Permission denied`:** workflow runs `chmod +x ./gradlew` before use. **Passed inspection; hosted execution not tested.**
9. **`materialButtonTextButtonStyle` unresolved reference:** UI uses Compose Material 3; source scan has no known View-system style reference of this name. **Static scan only; Kotlin compile not tested.**
10. **Wrong `HorizontalScrollView.LayoutParams`:** UI is Compose-based and should use Compose modifiers. **Static scan only; Kotlin compile not tested.**
11. **Compose `maxWidth` scope:** responsive UI source should use valid Compose scopes; this requires compiler confirmation. **NOT TESTED by Compose compiler.**
12. **Missing `PdfReaderScreen`:** this project is AI APK Builder Pro, not PDF Master; no `PdfReaderScreen` reference is required. Screen references for this project still need full Kotlin compilation. **Static project-scope check; Kotlin compile not tested.**

## Workflow behavior

The root `.github/workflows/build-apk.yml` builds the committed AI APK Builder Pro source on `push` or manual `workflow_dispatch`, then uploads `app/build/outputs/apk/debug/app-debug.apk` as `ai-apk-builder-pro-debug-apk`. Diagnostics are uploaded even after failure. The separate release-triggered builder workflow template remains at `app/src/main/assets/templates/build-apk.yml` for the app's intended service: building user-uploaded Android project ZIPs from private Release assets.
